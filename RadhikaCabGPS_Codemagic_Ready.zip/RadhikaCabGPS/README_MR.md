# Radhika Cab – GPS Fare Meter (Background GPS Edition)

## Features
- Single-driver Android app
- GPS fare at ₹25 per kilometre
- START / END trip controls
- Location tracking runs in an Android location foreground service while the screen is off or another app is in use
- Persistent foreground notification while a trip is active
- END opens the PAY IN CASH screen
- PDF bill save using Android's document picker
- CASH COLLECTED returns to the main screen

## Build settings
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.20
- Java/Kotlin bytecode target 17
- compileSdk 35 / targetSdk 35 / minSdk 26

## Permissions and usage
1. Install and open the app.
2. Grant **Precise location** permission. Location must be enabled on the phone.
3. On Android 13+, allow notifications so the ongoing trip notification is visible.
4. Press START while the app is open. Android requires a location foreground service to be started while the app is visible.
5. You can now lock the screen or switch to another app. The ongoing notification indicates GPS tracking is active.
6. Return to Radhika Cab and press END. The app calculates the fare and opens the cash payment screen.
7. On some phone brands, battery saver / auto-start restrictions may still stop background work. For reliable use, set battery usage for Radhika Cab to **Unrestricted / Don't optimize** and allow auto-start if the phone provides that setting.

## Important
- This is a source project ZIP, not an already-built APK.
- GPS distance can vary with signal quality, tunnels, tall buildings and device settings. Check the displayed distance before collecting fare.
- The app uses a foreground location service; it does not request `ACCESS_BACKGROUND_LOCATION` because the driver starts tracking from the visible app and the foreground service continues the active trip.
- Background operation must be tested on the actual Android phone before using for paid trips.
